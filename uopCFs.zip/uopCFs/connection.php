<?php 

$host = "localhost";
$DB = "uopcfs";
$user = "root";
$pass = "";

$connect = mysqli_connect($host, $user, $pass,  $DB);


?>