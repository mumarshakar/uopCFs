-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2024 at 07:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uopcfs`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `countryID` int(11) NOT NULL,
  `countryName` varchar(50) NOT NULL,
  `countrynd` varchar(50) NOT NULL,
  `countryndm` varchar(50) NOT NULL,
  `countryndy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`countryID`, `countryName`, `countrynd`, `countryndm`, `countryndy`) VALUES
(2, 'Pakistan', '14', 'August', '1947'),
(3, 'United States', '4', 'July', '1776'),
(4, 'India', '15', 'August', '1947'),
(5, 'Brazil', '07', 'September', '1822'),
(6, 'South Africa', '31', 'May', '1910'),
(7, 'Nigeria', '01', 'October', '1960'),
(8, 'Australia', '01', 'January', '1901'),
(9, 'Canada', '01', 'July', '1867'),
(10, 'Mexico', '16', 'September', '1810'),
(11, 'Egypt', '28', 'February', '1922'),
(12, 'Japan', '11', 'February', '660 BCE'),
(13, 'Libya', '24', 'Dec', '1951'),
(14, 'Afghanistan', '19', 'Aug', '1919'),
(15, 'Nigeria', '1', 'Oct', '1960'),
(16, 'Egypt', '22', 'Feb', '1922');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `stid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `role` varchar(15) NOT NULL,
  `groupname` varchar(20) NOT NULL,
  `emailaddress` varchar(50) NOT NULL,
  `country` varchar(20) NOT NULL,
  `countrynd` varchar(20) NOT NULL,
  `countryndm` varchar(10) NOT NULL,
  `countryndy` varchar(10) NOT NULL,
  `year` varchar(10) NOT NULL,
  `term` varchar(10) NOT NULL,
  `coursename` varchar(20) NOT NULL,
  `coursecode` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`stid`, `fname`, `lname`, `role`, `groupname`, `emailaddress`, `country`, `countrynd`, `countryndm`, `countryndy`, `year`, `term`, `coursename`, `coursecode`) VALUES
(1, 'Muhammad', 'Abdullah', 'Student', '', 'abdullahbajwa449@gmail.com', 'Pakistan', '14', 'August', '1947', 'AY2024', 'T3', 'English', 'ENG0008'),
(2, 'Housam', 'Aborasen', 'Student', '', 'mr.housamali@gmail.com', 'Libya', '24', 'December', '1951', 'AY2024', 'T3', 'English', 'ENG0008'),
(3, 'Muhammad', 'Ahmad', 'Student', '', 'muhammad.ahmad90@hotmail.com', 'Malaysia', '31', 'August', '1957', 'AY2024', 'T3', 'English', 'ENG0008'),
(4, 'Safowa ', 'Alhaj', 'Student', '', 'saf19912019@gmail.com', 'Sudan', '01', 'January', '1956', 'AY2024', 'T3', 'English', 'ENG0008'),
(5, 'Leen ', 'Alsamman', 'Student', '', 'leenals658@gmail.com', 'Syrian Arab Republic', '17', 'April', '1946', 'AY2024', 'T3', 'English', 'ENG0008'),
(6, 'Rana ', 'Alshik Ali', 'Student', '', 'rnoon85@gmail.com', 'Saudi Arabia', '23', 'September', '1932', 'AY2024', 'T3', 'English', 'ENG0008'),
(7, 'Nabila ', 'Amdouni', 'Student', '', '', 'Tunisia', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(8, 'Maria ', 'Bastos', 'Student', '', 'bastosmaria226@gmail.com', 'Namibia', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(9, 'Jonathan ', 'Belizaire', 'Student', '', 'jonatha23092001@gmail.com', 'Haiti', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(10, 'Sujan ', 'Bhusal', 'Student', '', 'sujan.bhusal2071@gmail.com', 'Nepal', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(11, 'Birkan ', 'Caglayan', 'Student', '', 'birkancaglayan52@gmail.com', 'Turkey', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(12, 'Phillip ', 'Dzamba\n', 'Student', '', 'dzambaphillip@gmail.com', 'South Africa', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(13, 'Fatima-Zahra', ' El Aanous', 'Student', '', 'elaanousfati@gmail.com', 'Morocco', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(14, 'Mohammed ', 'Farah', 'Student', '', 'farahbreezy15@gmail.com', 'United Arab Emirates', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(15, 'Tomoya ', 'Fukuchi', 'Student', '', 'ykswf556@hotmail.co.jp', 'Japan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(16, 'Marwiza ', 'Halimi', 'Student', '', 'halimi.marhaba2000@gmail.com', 'Afghanistan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(17, 'Maal ', 'Hamoda', 'Student', '', 'peacemakerwhiteheart@gmail.com', 'Sudan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(18, 'Yevheniia ', 'Ivanets', 'Student', '', 'jenyaivanetz@gmail.com', 'Ukraine', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(19, 'M Shah', ' Jawid', 'Student', '', 'eternalsecret2002@gmail.com', 'Afghanistan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(20, 'Songwoon ', 'Kang', 'Student', '', 'ksw6128@gmail.com', 'Korea (the Republic ', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(21, 'Reinaldo ', 'Martino', 'Student', '', 'martinoreinaldo7@gmail.com', 'United States', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(22, 'Yaoko', ' Matsuoka\n', ' Instructor', '', 'yaoko.matsuoka@uopeople.edu', 'Japan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(23, 'Daria', ' Podoba', 'Student', '', '', 'Ukraine', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(24, 'Almaz', ' Polatov', 'Student', '', 'almazik.dream@gmail.com', 'Kazakhstan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(25, 'Andrii ', 'Povroznyk', 'Student', '', 'a.povroznyk@creatio.com', 'Ukraine', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(26, 'Gerardo Sanchez', ' Garza', 'Student', '', 'noel.ggw@outlook.com', 'Mexico', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(27, 'Chu Sint', ' Nwe', 'Student', '', 'chusintnwe2661@gmail.com', 'Myanmar', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(28, 'Nann', ' Thet', 'Student', '', 'nannyinminthet130686@gmail.com', 'Myanmar', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(29, 'Parila', ' Wahiz', 'Student', '', 'hpari6249@gmail.com', 'Afghanistan', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(30, 'Mariana', ' Gil', 'Student', '', 'marianagila14@gmail.com', 'Colombia', '', '', '', 'AY2024', 'T3', 'English', 'ENG0008'),
(31, 'EIMAN', 'ABDEL REHMAN', 'Student', '', 'eiman.azeemyagoub@gmail.com', 'SUDAN', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(32, 'Nebil', 'Ahmed', 'Student', '', 'nebilnasir24@gmail.com', 'Ethiopia', '', '', '', '', '', '', ''),
(34, 'Amira', 'Al Mokhalalaty', 'Student', '', 'amira2003kd@gmail.com', 'Saudi Arabia', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(35, 'Shafag', 'Ali', 'Student', '', 'shafaq959@hotmail.com', 'Sudan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(36, 'MARAM', 'AHMAD', 'Student', '', 'muram381@gmail.com', 'SUDAN', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(37, 'Alaa', 'Almadi', 'Student', '', 'alaa.almadi.2016@gmail.com', 'Sweden', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(38, 'Mehedi', 'Hassan Bappy', 'Student', '', 'mehedihasanbappi653@gmail.com', 'Bangladesh', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(39, 'Katherine', 'Burton', 'Instructor', '', 'katherine.burton@uopeople.edu', 'United States', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(40, 'Noufissa', 'El Hassany', 'Student', '', 'noufnoufisa@gmail.com', 'Morocco', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(41, 'Ayaanle', 'Elmi', 'Student', '', 'ayaanlehussein1960@gmail.com', 'Somalia', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(42, 'Alex', 'Euzebio', 'Student', '', 'alexjuliano624@gmail.com', 'Brazil', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(43, 'Ibrahim', 'Shawkat Hamoo', 'Student', '', 'ibrahimhamoo396@gmail.com', 'Syrian Arab Republic', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(44, 'Syed', 'Hijazi', 'Student', '', 'zubairhijazi.2@gmail.com', 'Pakistan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(45, 'Md Shahadat', 'Hossain', 'Student', '', 'bappy@sofos.one', 'Bangladesh', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(46, 'Mohamed', 'Ibrahim', 'Student', '', 'mohamed1122333ahmed@gmail.com', 'Egypt', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(47, 'Md Mazharul', 'Islam', 'Student', '', 'mazharul1989@yahoo.com', 'Bangladesh', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(48, 'Md Jamal', 'Khan', 'Student', '', 'jamal.bd18@gmail.com', 'Bangladesh', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(49, 'Sara', 'Khidir', 'Student', '', 'saramo65na70@gmail.com', 'Sudan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(50, 'Bibi Maryam', 'Leeda', 'Student', '', 'marleeshaheed@gmail.com', 'Afghanistan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(51, 'Ibrahim', 'Magdi', 'Student', '', 'ibrahim19991018@gmail.com', 'Sudan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(52, 'Uthan', 'Marma', 'Student', '', 'uthanmarmaais@gmail.com', 'Bangladesh', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(53, 'Nilofar', 'Mehrabi', 'Student', '', 'nilofarmehrabi760@gmail.com', 'Afghanistan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(54, 'Bibi Farishta', 'Muhammad Bakhtiar', 'Student', '', 'bibifarishta65@gmail.com', 'United Arab Emirates', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(55, 'Mansoor', 'Niazi', 'Student', '', 'mansoorniazi95@gmail.com', 'United States', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(56, 'Satrio', 'Nugroho', 'Student', '', 'satriown10@gmail.com', 'Indonesia', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(57, 'Ailene', 'Pesquiza', 'Student', '', 'a0988469276@gmail.com', 'Philippines', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(58, 'Souhib', 'Saadi', 'Student', '', 'saadisohayb33@gmail.com', 'Qatar', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(59, 'Mohammed', 'Saki', 'Student', '', 'sakimohammed93@gmail.com', 'Morocco', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(60, 'Razan', 'Salih', 'Student', '', 'razanahmadsalih@gmail.com', 'Sudan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(61, 'Shahzaib', 'Samo', 'Student', '', 'shahzaibalisamoo526@gmail.com', 'Pakistan', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(62, 'Naveen', 'Sehar', 'Student', '', 'nvnsehar@gmail.com', 'United Arab Emirates', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(63, 'Liubov', 'Shuvalova', 'Student', '', 'lubov.menshih@gmail.com', 'Russian Federation', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(64, 'Mohammad', 'Taha', 'Student', '', 'm7madtoon@gmail.com', 'Saudi Arabia', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(65, 'Yordanos', 'Tefera', 'Student', '', 'gt.yordanos@gmail.com', 'Ethiopia', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(66, 'Oliver', 'Villaverde', 'Student', '', 'oliver.villaverde@gmail.com', 'Philippines', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(67, 'Akbarali', 'Yulchiev', 'Student', '', 'ayulchiev777@gmail.com', 'United States', '', '', '', 'AY2023', 'T2', 'English', 'ENG0008'),
(88, 'Brian ', 'Ajeny', 'Student', 'Group 0062', 'BrianAjeny@my.uopeople.edu', 'Kenya', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(89, 'Mariam ', 'Akhmed', 'Student', 'Group 0062', 'mariamw2210@gmail.com', 'Egypt', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(90, 'Maisam', 'Alrahimi', 'Student', 'Group 0062', 'NIL', 'United States', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(91, 'Aleadra ', 'Aryeetey', 'Student', 'Group 0062', 'aleadra105@gmail.com', 'Ghana', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(92, 'Thiri ', 'Aung Thu', 'Student', 'Group 0062', 'thiriaungthu2001@gmail.com', 'Myanmar', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(93, 'Yana ', 'Borysovska', 'Student', 'Group 0062', 'hanahaki.yoohee@gmail.com', 'Cyprus', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(94, 'Yichen ', 'Chung', 'Student', 'Group 0062', 'anychung089@gmail.com', 'Japan', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(95, 'Delianur ', 'Delianur', 'Student', 'Group 0062', 'delianur@yahoo.com', 'Indonesia', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(96, 'Makokha ', 'Dennis', 'Student', 'Group 0062', 'dewabzier@gmail.com', 'Kenya', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(97, 'Fatuma ', 'Farah', 'Student', 'Group 0062', 'honeyey77@gmail.com', 'Kenya', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(98, 'Kevin ', 'Fisch', 'Student', 'Group 0062', 'kjfisch@gmail.com', 'Namibia', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(99, 'Muhammad ', 'Irfan', 'Student', 'Group 0062', 'irfan.uopeople@gmail.com', 'Pakistan', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(100, 'Samuel ', 'Azubuike James', 'Student', 'Group 0062', 'jamessamuel017@gmail.com', 'Nigeria', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(101, 'Junior ', 'Kamtchoua', 'Student', 'Group 0062', 'kamtchouajunior@gmail.com', 'Cameroon', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(102, 'Canisious ', 'Kufazvinei', 'Student', 'Group 0062', 'kufazvineic@gmail.com', 'Zimbabwe', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(103, 'Elisha ', 'Matabile', 'Student', 'Group 0062', 'elishaalaxanderk01@gmail.com', 'Zambia', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(104, 'Anita ', 'Modi', 'Student', 'Group 0062', 'nyubang26@gmail.com', 'Niger', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(105, 'Mohamed ', 'Mohamed', 'Student', 'Group 0062', 'NIL', 'Somalia', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(106, 'Israel ', 'Mokgwetsi', 'Student', 'Group 0062', 'izymokgwetsana@gmail.com', 'South Africa', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(107, 'Makughoambom ', 'Mokunyu', 'Student', 'Group 0062', 'makughoambommicah0134@gmail.com', 'Cameroon', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(108, 'Steven ', 'Musonda', 'Student', 'Group 0062', 'musondasteven2013@gmail.com', 'Congo', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(109, 'Rameen ', 'Naseer Uddin', 'Student', 'Group 0062', 'rameennaseer18@gmail.com', 'Pakistan', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(110, 'Thembelihle ', 'Nxumalo', 'Student', 'Group 0062', 'thembelihlenxumalo6@gmail.com', 'Eswatini', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(111, 'Akeer ', 'Nyok', 'Student', 'Group 0062', 'akeerkuolmalualnyok@gmail.com', 'South Sudan', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(112, 'Tyron ', 'Palmerston', 'Student', 'Group 0062', 'ps4paltj@gmail.com', 'Belize', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(113, 'Nathali ', 'Preciado Orjuela', 'Student', 'Group 0062', 'natha_po@hotmail.com', 'United Arab Emirates', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(114, 'Uttiya ', 'Sarkar ', 'Instructor', 'Group 0062', 'uttiya.sarkar@uopeople.edu', 'India', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(115, 'Shahad ', 'Sharmarke Mahmoud', 'Student', 'Group 0062', 's2715477@gmail.com', 'Somalia', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(116, 'Alice ', 'Sibindi', 'Student', 'Group 0062', 'sibindidanisa@gmail.com', 'Zimbabwe', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(117, 'Gladness ', 'Simelane', 'Student', 'Group 0062', 'gamedzempumie307@gmail.com', 'Eswatini', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(118, 'Rime ', 'Sisal', 'Student', 'Group 0062', 'rimesisal@gmail.com', 'Malaysia', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(119, 'Anargul ', 'Temirgaliyeva', 'Student', 'Group 0062', 'NIL', 'Kazakhstan', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(120, 'Keizo ', 'Tsutano', 'Student', 'Group 0062', 'KeizoTsutano@my.uopeople.edu', 'Japan', '', '', '', 'AY202', 'T5', 'English Composition ', 'ENGL 1102-'),
(121, 'Kailee ', 'Chaparro', 'Student', 'Group 0010', 'kaichap1122@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(122, 'Stephen ', 'Chengo', 'Student', 'Group 0010', 'stephencharo20@gmail.com', 'Kenya', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(123, 'Mariia ', 'Cherkas', 'Student', 'Group 0010', 'mariacherkas2006@gmail.com', 'Germany', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(124, 'Iruaku Peniel', 'Chukwuogo', 'Student', 'Group 0010', 'iruakupenielchukwuogo@my.uopeople.edu', 'Nigeria', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(125, 'Marlon Fabian', 'Corona-Dellan', 'Student', 'Group 0010', 'm.coronadellan@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(126, 'James ', 'Eddy', 'Student', 'Group 0010', 'moinkandkilo@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(127, 'Dinnel ', 'Emmanuel', 'Student', 'Group 0010', 'dinneledu@gmail.com', 'Saint Lucia', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(128, 'Luca ', 'Flati', 'Student', 'Group 0010', 'lucaflati@yahoo.com', 'Italy', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(129, ' Cris John', 'Fuentes', 'Student', 'Group 0010', 'lukestart19990@gmail.com', 'Philippines', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(130, 'Grace ', 'Guste', 'Student', 'Group 0010', 'guste.grace@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(131, 'Bhadmus ', 'Henry', 'Student', 'Group 0010', 'bhadmushenry9@gmail.com', 'Nigeria', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(132, 'Denys ', 'Karpov', 'Student', 'Group 0010', 'denys.karpov.eng@gmail.com', 'Ukraine', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(133, 'Julius ', 'Lancelot', 'Student', 'Group 0010', 'julius.lancelot@highways.gov.gh', 'Ghana', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(134, 'Victor ', 'Leitinho', 'Student', 'Group 0010', 'vrleitinho@gmail.com', 'Brazil', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(135, 'Abdulmalik ', 'Mohsen', 'Student', 'Group 0010', 'd70y11@gmail.com', 'Saudi Arabia', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(136, 'Eleanore ', 'Nary', 'Student', 'Group 0010', 'eleanore.nary@gmail.com', 'Finland', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(137, 'Alfred ', 'Okeng', 'Student', 'Group 0010', 'alfredokeng40@gmail.com', 'Uganda', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(138, 'Ifeanyi ', 'Onyekwe', 'Student', 'Group 0010', 'ify.theo@gmail.com', 'Kazakhstan', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(139, 'Kimberly ', 'Pingenot', 'Student', 'Group 0010', 'kpingenot@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(140, 'Saqib ', 'Sadiq ', 'Instructor', 'Group 0010', 'saqib.sadiq@uopeople.edu', 'Pakistan', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(141, 'Gustavo ', 'Sanchez Olea', 'Student', 'Group 0010', 'sanchezoleagustavo@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(142, 'Danilo ', 'Strapasson', 'Student', 'Group 0010', 'dnstrap@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(143, 'Joseph ', 'Todora', 'Student', 'Group 0010', 'jptodora@gmail.com', 'United States', '', '', '', 'AY2024', 'T5', 'Programming (Java)', 'CS1102.01'),
(144, 'Joseph ', 'Abah', 'Student', 'Group 0020', 'joefazee@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(145, 'Sohaib ', 'Abdullah', 'Student', 'Group 0020', 'sohaib1abdullah@gmail.com', 'Saudi Arabia', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(146, 'Silas ', 'Adem', 'Student', 'Group 0020', 'silasowitiadem@gmail.com', 'Kenya', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(147, 'Samir ', 'Afridi', 'Student', 'Group 0020', 'samir.afridi1@gmail.com', 'Tajikistan', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(148, 'Stephen ', 'Agbapuru', 'Student', 'Group 0020', 'stephenagbapuru@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(149, 'Wisdom ', 'Anthony', 'Student', 'Group 0020', 'wisdomorok@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(150, ' Jose', 'Antony ', 'Instructor (Sen', 'Group 0020', 'jose.antony@uopeople.edu', 'India', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(151, 'Abdulsamad ', 'Bangura', 'Student', 'Group 0020', 'samadabangs90@gmail.com', 'Sierra Leone', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(152, 'Dagmawi ', 'Berhanu', 'Student', 'Group 0020', 'dagmawiyibeltal@yahoo.com', 'Ethiopia', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(153, 'Joseph ', 'Chilufya', 'Student', 'Group 0020', 'josephchilu7@gmail.com', 'Zambia', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(154, 'Cyra ', 'Dimpoy', 'Student', 'Group 0020', 'cdimpoy@gmail.com', 'Philippines', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(155, 'Zipporah ', 'Divine', 'Student', 'Group 0020', 'divineimmi@gmail.com', 'Indonesia', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(156, 'Nsisong Nsikan', 'Dominic', 'Student', 'Group 0020', 'nsisongakpabio5@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(157, 'Angela ', 'Dumorne', 'Student', 'Group 0020', 'dumorneangela@icloud.com', 'Haiti', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(158, 'Ian ', 'Githinji', 'Student', 'Group 0020', 'igithinji432@gmail.com', 'Kenya', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(159, 'Salvation ', 'Israel', 'Student', 'Group 0020', 'NIL', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(160, 'Chibuzor ', 'Iwuchukwu', 'Student', 'Group 0020', 'Chicargo205@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(161, 'Tashinga ', 'Majonga', 'Student', 'Group 0020', 'majongatashinga010@gmail.com', 'United Arab Emirates', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(162, 'Stefanie ', 'Mccowan', 'Student', 'Group 0020', 'stefaniecynewski@msn.com', 'United States', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(163, 'Natalie ', 'Mcdonald', 'Student', 'Group 0020', 'natalie.elaine.mcd@gmail.com', 'United States', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(164, 'Lesego Alec', 'Lecco Medupe', 'Student', 'Group 0020', 'leshmedupe@gmail.com', 'Botswana', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(165, 'Tebelo ', 'Morafo', 'Student', 'Group 0020', 'tebelomorafo@gmail.com', 'Lesotho', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(166, 'Lewis ', 'Mugo', 'Student', 'Group 0020', 'mutemugo381@gmail.com', 'Kenya', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(167, 'Muhamad Danieal Azim', 'Bin Muhamad Asri', 'Student', 'Group 0020', 'daniealasri@gmail.com', 'Malaysia', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(168, 'Nabina ', 'Niraula', 'Student', 'Group 0020', 'nabina0301@gmail.com', 'United States, Nepal', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(169, 'Kelvin Micheal', 'Njau', 'Student', 'Group 0020', 'michaelnganga.njau@gmail.com', 'Kenya', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(170, 'Esther ', 'Nwachukwu', 'Student', 'Group 0020', 'esthernwachukwu.en@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(171, 'Nang Ywat', 'Phong Ohm', 'Student', 'Group 0020', 'yordphongohm@gmail.com', 'Myanmar', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(172, 'Olalekan ', 'Olayemi', 'Student', 'Group 0020', 'yemimatin03@gmail.com', 'Nigeria', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(173, 'Josphat ', 'Omondi', 'Student', 'Group 0020', 'jostosha@gmail.com', 'Kenya', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(174, 'Adam ', 'Pechtinger', 'Student', 'Group 0020', 'NIL', 'Hungary', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(175, 'Loraine ', 'Sibanda', 'Student', 'Group 0020', 'lorahsibbs@gmail.com', 'South Africa', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(176, 'Pramod ', 'Sigdel', 'Student', 'Group 0020', 'pramodsigdel333@gmail.com', 'Japan', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(177, 'Peter ', 'Starkey', 'Student', 'Group 0020', 'peter.a.starkey@gmail.com', 'United States', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(178, 'Abdul Maajid', 'Sufianu', 'Student', 'Group 0020', 'sufianabdulmaajid@gmail.com', 'Ghana', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(179, 'Muhammad ', 'Wassam', 'Student', 'Group 0020', 'malikwassam302@gmail.com', 'Pakistan', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(180, 'Beth ', 'Watson', 'Student', 'Group 0020', 'bethandshanew@gmail.com', 'United States', '', '', '', 'Ay2025', 'T1', 'Principles of Busine', 'BUS 1101-01'),
(181, 'Deepika ', 'Dhamija', 'Instructor', 'NIL', 'Nil', 'India', '', '', '', 'AY2024', 'T4', 'Fundamentals Of Prog', 'CS1101.01'),
(182, 'Michael ', 'Mirra', 'Instructor', 'NIL', 'NIL', 'United States', '', '', '', 'AY2024', 'T4', 'Online Education Str', 'OES'),
(183, 'Muhammad Umar', 'Muhammad Umar SHakar', 'Student', 'Group 0020', 'umarshakar@gmail.com', 'United States', '', '', '', 'AY2024', 'T1', 'Principles of Busine', 'BUS 1101-01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`countryID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`stid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `countryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=184;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
